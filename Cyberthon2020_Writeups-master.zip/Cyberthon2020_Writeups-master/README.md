## Cyberthon 2020 Writeups
Written by: hci-1

### Network Security
* [x] What was Leaked
* [x] Baba Supplier's Chat
* [x] Text is the key
* [x] Macnificent Authentication
* [x] Loosen That Ratchet
* [x] Patience is Key Element of Success

### Operating Systems
* [x] Treasure Hunt
* [x] Simple Cipher
* [x] Find The Answers ([also done by HCI_Zheng Jun](https://cdn.discordapp.com/attachments/706068116324614144/706886532073521172/FTA_Updated.pdf))
* [ ] Meow ([done by HCI_Zheng Jun](https://cdn.discordapp.com/attachments/706068116324614144/706149649567711252/Meow.pdf))
* [x] Reverse(Faze)

### Web Services
* [x] Baba-OAuth
* [X] Vote
* [x] Search high and low, you should. Yeesssssss
* [x] Caged Up
* [x] WikiShellFall (somewhat incomplete)

### CSIT
* [X] Lost Magic
* [ ] Heart Paint ([done by ACSI_Jonathan](https://jloh02.github.io/ctf/cyberthon-2020#heart-paint))
* [x] The ROPster
* [ ] Unravelling DGA ([done by 000verflow](https://cdn.discordapp.com/attachments/706068116324614144/706141518590640178/Unravelling_DGA.pdf))
* [x] From 8 to 5
* [x] What You See is Not all That Exists

### Data Science
* [ ] Find The Hacker ID ([done by EJC_RichardDominick](https://github.com/RichDom2185/Cyberthon-2020/blob/master/Data%20Science/FindTheHackerID.ipynb))
* [ ] My New Language ([done by NYJC_Terence](https://github.com/Hackin7/Programming-Crappy-Solutions/tree/master/Cyber%20Security/Cyberthon%202020/Finals/Data%20Science/My%20New%20Language))
* [ ] Spot The Malicious Users ([done by ACSI_Jonathan](https://jloh02.github.io/ctf/cyberthon-2020#spot-the-malicious-users))
* [ ] Parsing Events ([Python file available here](https://cdn.discordapp.com/attachments/706068116324614144/706085061211979797/test.py))
